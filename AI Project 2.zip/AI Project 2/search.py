import matplotlib.pyplot as plt
import numpy as np
import time
import matplotlib.animation as animation
from shapely.geometry import Polygon, Point, LinearRing
from random import uniform

from utils import *
from grid import Pt
from grid import *
from node import *
from problem import *
     
def dfs(problem):
    start = Node(problem.initial.x, problem.initial.y)   
    goal = Node(problem.goal.x, problem.goal.y)
    visited = [start]
    frontier = [start]
    while len(frontier)>0:
        currNode = frontier.pop()
        expanded = expand(currNode)
        expanded.clear
        if currNode.x == goal.x and currNode.y == goal.y:
            path = []
            while currNode is not None:
                path.append(Pt(currNode.x, currNode.y))
                currNode = currNode.parent
                return path[::-1]
        expanded = expand(currNode)
        for node in expanded:
            for i in range(len(visited)):
                if node.x == visited[i].x and node.y == visited[i].y: #problem area
                    print(visited[i].x, visited[i].y)
                    continue
            #print(node.x, node.y)

            visited.append(node) 
            frontier.append(node)

    return []
            
def BFS(problem):
    start = Node(problem.initial.x, problem.initial.y)
    goal = Node(problem.goal.x, problem.goal.y)
    frontier = Queue()
    frontier.push(start)
    reached = []

    while not frontier.isEmpty():
        currNode = frontier.get()

        if currNode.x == goal.x and currNode.y == goal.y:
            path = []
            while currNode is not None:
                # add the point to the path
                path.append(Pt(currNode.x, currNode.y))
                currNode = currNode.parent

            return path[::-1]

        if currNode.value in reached:
            continue

        reached.append(currNode.value)

        for node in expand(currNode):
            if node in reached:
                new_node = Node(node.x, node.y)
                frontier.put(new_node)

    return []           
        

def gen_polygons(worldfilepath):
    polygons = []
    with open(worldfilepath, "r") as f:
        lines = f.readlines()
        lines = [line[:-1] for line in lines]
        for line in lines:
            polygon = []
            pts = line.split(';')
            for pt in pts:
                xy = pt.split(',')
                polygon.append(Pt(int(xy[0]), int(xy[1])))
            polygons.append(polygon)
    return polygons

def expand(currNode):
    actions = []
    obstacles = []
    visited = []
    obstacles = inside(0,0)
    currNode = Node(currNode.x, currNode.y)
    up = Node(currNode.x, currNode.y+1)
    right = Node(currNode.x+1, currNode.y)
    down = Node(currNode.x, currNode.y-1)
    left = Node(currNode.x-1, currNode.y)
    if up not in obstacles and up.y >= 0 and up.y < 50:
        actions.append(up)
        visited.append(up)
        if up in visited:
            actions.pop
    if right not in obstacles and right.x >= 0 and right.x < 50:
        actions.append(right)
        visited.append(right)
        if right in visited:
            actions.pop
    if down not in obstacles and down.y >= 0 and down.y < 50:
        actions.append(down)
        visited.append(down)
        if down in visited:
            actions.pop
    if left not in obstacles and left.x >= 0 and left.x < 50:
        actions.append(left)
        visited.append(left)
        if left in visited:
            actions.pop
    return actions
            

def inside(i, j):
    i = 0
    j = 0
    obs = set()
    while j < 50:
        point = Point(i, j)
        linearRing1 = LinearRing(list(obstacles[0].exterior.coords))
        linearRing2 = LinearRing(list(obstacles[1].exterior.coords))
        linearRing3 = LinearRing(list(obstacles[2].exterior.coords))
        linearRing4 = LinearRing(list(obstacles[3].exterior.coords))

        if(obstacles[0].contains(point) or obstacles[1].contains(point) or obstacles[2].contains(point) or obstacles[3].contains(point) or linearRing1.contains(point) or linearRing2.contains(point) or linearRing3.contains(point) or linearRing4.contains(point)):
            obs.add(point)

        i += 1
        if(i > 49):
            i = 0
            j += 1
    return obs


if __name__ == "__main__":
    
    epolygons = gen_polygons('TestingGrid/world1_enclosures.txt')
    #epolygons = gen_polygons('TestingGrid/world2_enclosures.txt')
    tpolygons = gen_polygons('TestingGrid/world1_turfs.txt')
    #######################################################################################################################################################################################################################################################################
    #define obstacles objects using shapely
    #######################################################################################################################################################################################################################################################################
    coords1x = []
    coords1y = []
    coords2x = []
    coords2y = []
    coords3x = []
    coords3y = []
    coords4x = []
    coords4y = []
    obstacles = []
    tcoords1x = []
    tcoords1y = []
    tcoords2x = []
    tcoords2y = []
    turfs = []
    

    for i in range(len(epolygons[0])):
        coords1x.append(epolygons[0][i].x)
        coords1y.append(epolygons[0][i].y)
        
    poly1 = Polygon(list(zip(coords1x, coords1y)))
        
    for i in range(len(epolygons[1])):
        coords2x.append(epolygons[1][i].x)
        coords2y.append(epolygons[1][i].y)
        
    poly2 = Polygon(list(zip(coords2x, coords2y)))
        
    for i in range(len(epolygons[2])):
        coords3x.append(epolygons[2][i].x)
        coords3y.append(epolygons[2][i].y)
        
    poly3 = Polygon(list(zip(coords3x, coords3y)))
        
    for i in range(len(epolygons[3])):
        coords4x.append(epolygons[3][i].x)
        coords4y.append(epolygons[3][i].y)
        
    poly4 = Polygon(list(zip(coords4x, coords4y)))
        
    obstacles.append(poly1)
    obstacles.append(poly2)
    obstacles.append(poly3)
    obstacles.append(poly4)
    
    for i in range(len(tpolygons[0])):
        tcoords1x.append(tpolygons[0][i].x)
        tcoords1y.append(tpolygons[0][i].y)
        
    tpoly1 = Polygon(list(zip(tcoords1x, tcoords1y)))
    
    for i in range(len(tpolygons[1])):
        tcoords1x.append(tpolygons[1][i].x)
        tcoords1y.append(tpolygons[1][i].y)
        
    tpoly2 = Polygon(list(zip(tcoords2x, tcoords2y)))
    
    turfs.append(tpoly1)
    turfs.append(tpoly2)
#######################################################################################################################################################################################################################################################################
########################################################################################################################################################################################################################################################################

    source = Node(8,10)
    dest = Node(43,45)
    
    

    fig, ax = draw_board()
    draw_grids(ax)
    draw_source(ax, source.x, source.y)  # source point
    draw_dest(ax, dest.x, dest.y)  # destination point
    obs = inside(0, 0)
    
    #Draw enclosure polygons
    for polygon in epolygons:
        for p in polygon:
            draw_point(ax, p.x, p.y)
    for polygon in epolygons:
        for i in range(0, len(polygon)):
            draw_line(ax, [polygon[i].x, polygon[(i+1)%len(polygon)].x], [polygon[i].y, polygon[(i+1)%len(polygon)].y])
    
    #Draw turf polygons
    for polygon in tpolygons:
        for p in polygon:
            draw_green_point(ax, p.x, p.y)
    for polygon in tpolygons:
        for i in range(0, len(polygon)):
            draw_green_line(ax, [polygon[i].x, polygon[(i+1)%len(polygon)].x], [polygon[i].y, polygon[(i+1)%len(polygon)].y])

    ### Here call your search to compute and collect res_path
    problem = Problem(source, dest)
    res_path = dfs(problem)

    
    for i in range(len(res_path)-1):
        draw_result_line(ax, [res_path[i].x, res_path[i+1].x], [res_path[i].y, res_path[i+1].y])
        plt.pause(0.1)
    
    plt.show()

