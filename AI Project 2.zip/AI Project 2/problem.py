from node import *


class Problem:
    def __init__(self, initial, goal):
        self.initial = initial
        self.goal = goal
