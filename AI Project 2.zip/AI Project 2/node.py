from problem import *
from grid import *

class Node:
    def __init__(self, x, y, parent=None, pathCost=0):
        self.x = x
        self.y = y
        self.parent = parent
        self.pathCost = pathCost
    
    def get_xy(self):
        """
        Returns a tuple (x, y) representing the node's coordinates.
        """
        return self.x, self.y

