I used shapely in this project It properly identified the objects and turfs. However when it comes to the algoriths themselves 
I couldnt get it to stop infinietly looping. I feel as though this project would have benefitted from some more specific examples as 
I know i personally havent worked with gui software in python let alone search a gui grid with AI algos. I accept whatever grade given as ive spent 
the last week straight staring at this and i give up (in the best way possible). you will need to install Shapely to run this code.