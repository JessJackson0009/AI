from pysat.formula import CNF
from pysat.solvers import Solver

def parse_attributes(file_name):
    with open(file_name, 'r') as file:
        contents = file.readlines()

    parsed_contents = {}
    order = {}
    i = 0
    for line in contents:
        category, items = line.strip().split(':')
        tempItem = items.split(",")
        items = []
        for item in tempItem:
            items.append(item.strip())
        parsed_contents[category] = items
        order[i] = category
        i+= 1
        
    return parsed_contents

def order(file_name):
    with open(file_name, 'r') as file:
        contents = file.readlines()

    parsed_contents = {}
    order = {}
    i = 0
    for line in contents:
        category, items = line.strip().split(':')
        tempItem = items.split(",")
        items = []
        for item in tempItem:
            items.append(item.strip())
        parsed_contents[category] = items
        order[i] = category
        i+= 1
        
    return order

def parse_constraints(file_name):
    with open(file_name, 'r') as file:
        contents = file.readlines()

    parsed_constraints = []
    for line in contents:
        constraint = [ x for x in line.strip().split(" ")]
        parsed_constraints.append(constraint)

    return parsed_constraints

def parseQual(file_name):
    with open(file_name, 'r') as file:
        contents = file.readlines()
        
    Qual = []
    for line in contents:
        Qual.append(line.strip())
    return Qual

def parsePenaltyLogic(file_name):
    pen = []
    with open(file_name, 'r') as file:
        for line in file:
            parts = line.strip().split(',')
            rule = parts[0].strip()
            penaltyVal = int(parts[1].strip())
            pen.append((rule, penaltyVal))
    return pen

def new_menu():
    print("Choose the reasoning task to perform:")
    print("1. Encoding")
    print("2. Feasibility Checking")
    print("3. Show the Table")
    print("4. Exemplification")
    print("5. Omni-optimization")
    print("6. Back to previous menu")
    
def toBinary(parsed_attributes, order):
    encodedAttr = {}
    coded = []
    numOfKeys = len(parsed_attributes.keys())
    numOfOptions = pow(2, numOfKeys)
    for i in range(numOfOptions):
        hexString = '{0:0' + str(numOfKeys)+ 'b}'
        Binary = hexString.format(i)
        for j in range(numOfKeys):
            value = parsed_attributes.get(order[j])
            item = 1 - int(Binary[j])
            coded.append(value[item])
        encodedAttr[Binary] = coded
    for values in encodedAttr.items():
        i = 0
        print(f"o: {', '.join(values)}")
        i += 1
    return encodedAttr

if __name__ == "__main__":
    true = True
    while true:
        print("Welcome to PrefAgent")
        attributes = input("Enter attributes file name:")
        parsed_attributes = parse_attributes(attributes)
        Order = order(attributes)
        constraints = input("Enter hard constraints file name:")
        parsed_constraints = parse_constraints(constraints)

        print("Choose the preference logic to use:")
        print("1. Penalty Logic")
        print("2. Qualitative Choice Logic")
        print("3. Exit")

        inp = input()
        if inp == "1":
            print("You picked Penalty Logic")
            prefName = input("Enter preferences filename: ")
            parsed_P = parsePenaltyLogic(prefName)
            for i in range(len(parsed_P)):
                print(parsed_P[i])
    ## parse pref file
            newInput = '0'
            while newInput != '6':
                new_menu()
                newInput = input()
                if(newInput == "1"):
                    binrep = toBinary(parsed_attributes, Order)
                if(newInput == "2"):
                    cnf = CNF(from_clauses=[[-2, -1]])
                    with Solver(bootstrap_with=cnf) as solver:
                        print('formula is', f'{"s" if solver.solve() else "uns"}atisfiable')
                        print('and the model is:', solver.get_model())
                        print('here are all the models for this formula:')
                        for m in solver.enum_models():
                            print(m)
                if(newInput == "3"):
                    pass
                if(newInput == "4"):
                    pass
                if(newInput == "5"):
                    pass
                if(newInput == "6"):
                    pass
                else:
                    continue
        if inp == "2":
            print("You picked Qualitative Logic")
            prefName = input("Enter preferences filename: ")
            parsed_QL = parseQual(prefName)
            for i in range(len(parsed_QL)):
                print(parsed_QL[i])
        ##parse pref file
            newInput = '0'
            while newInput != '6':
                new_menu()
                newInput = input()
                if(newInput == "1"):
                    binrep = toBinary(parsed_attributes, Order)
                if(newInput == "2"):
                    cnf = CNF(from_clauses=[[-2, -1]])
                    with Solver(bootstrap_with=cnf) as solver:
                        print('formula is', f'{"s" if solver.solve() else "uns"}atisfiable')
                        print('and the model is:', solver.get_model())
                        print('here are all the models for this formula:')
                        for m in solver.enum_models():
                            print(m)
                if(newInput == "3"):
                    pass
                if(newInput == "4"):
                    pass
                if(newInput == "5"):
                    pass
                if(newInput == "6"):
                    pass
                else:
                    print("try again")
                    continue
        if inp == '3':
            print("bye")
            break
        else:
            continue

