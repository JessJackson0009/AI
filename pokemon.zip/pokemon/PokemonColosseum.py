import csv
import ast
import Pokemon
import random
from Pokemon import Moves
from Pokemon import Poke

pokemon_filename = 'pokemon-data.csv'
moves_filename = 'moves-data.csv'
header = []
pokemon_moves_data = []
pokemon_moves = {}
PokemonList = []
playerTeam = []
teamRocket = []
pokeMoves = []
emptyList = []
#-------------------------------------------------------------------------------------------------------------------------
#create list of pokemon objects
#-------------------------------------------------------------------------------------------------------------------------
with open(pokemon_filename) as csvfile:
    reader = csv.reader(csvfile, delimiter=',')
    header = next(reader)
    m = []
    for row in reader:
        n = row[0]
        t = row[1]
        H = row[2]
        a = row[3]
        d = row[4]
        h = row[5]
        w = row[6]
        m = row[7]
        poke = Poke(n, t, H, a, d, m, h, w) #loading object parameters into object class of pokemon
        PokemonList.append(poke) #loading each pokemon object into a list of pokemon data       
#-------------------------------------------------------------------------------------------------------------------------
#create dictionary of what moves each pokemon has
#-------------------------------------------------------------------------------------------------------------------------
pokemon_filename = 'pokemon-data.csv'
header = []
pokemon_moves = {}

with open(pokemon_filename) as csvfile:
    reader = csv.reader(csvfile, delimiter=',')
    header = next(reader)
    for row in reader:
        moves=''
        end_of_moves=False
        for s in row:
            if s[0]=='[':
                end_of_moves = True
                moves = s
            elif end_of_moves == True:
                moves += ','+s
                if s[-1] == ']':
                    end_of_moves = False
        pokemon_moves[row[0]] = ast.literal_eval(moves) # loading pokemon moves into their own seperate dictionary      
#-------------------------------------------------------------------------------------------------------------------------
#create list of moves and their data
#-------------------------------------------------------------------------------------------------------------------------
with open(moves_filename) as csvfile:
    reader = csv.reader(csvfile, delimiter=',')
    header = next(reader)
    for row in reader:
        N = row[0]
        T = row[1]
        Cat = row[2]
        Con = row[3]
        PP = row[4]
        Power = row[5]
        Acc = row[6]
        move = Moves(N, T, Cat, Con, PP, Power, Acc) #loading object parameters into object class of move
        pokemon_moves_data.append(move) #loading each move object into a list of move data 
#-------------------------------------------------------------------------------------------------------------------------
#game start text
#-------------------------------------------------------------------------------------------------------------------------
print("\nWelcome to Pokemon Colosseum!\n")
playerName = input("Enter Player Name: ")
#-------------------------------------------------------------------------------------------------------------------------
#loading random pokemon in playerTeam
#-------------------------------------------------------------------------------------------------------------------------
i = 1
while i < 4:
    randomPoke = (PokemonList.pop(random.randrange(len(PokemonList))))
    playerTeam.append(randomPoke)
    PokemonList.append(randomPoke)
    i += 1
PokemonList.append(randomPoke)
print("\nTeam "+ playerName + " enters with " + playerTeam[0].name + ", " + playerTeam[1].name + ", and " + playerTeam[2].name + ".")    
#-------------------------------------------------------------------------------------------------------------------------
#loading random pokemon into team rocket
#-------------------------------------------------------------------------------------------------------------------------
x = 1    
while x < 4:
    ranPoke = (PokemonList.pop(random.randrange(len(PokemonList))))
    teamRocket.append(ranPoke)
    PokemonList.append(ranPoke)
    x += 1 
PokemonList.append(ranPoke) 
print("\nTeam Rocket enters with " + teamRocket[0].name + ", " + teamRocket[1].name + ", and " + teamRocket[2].name + ".\n")   
print("\nLet the battle begin!\n")
#-------------------------------------------------------------------------------------------------------------------------
#coin toss
#-------------------------------------------------------------------------------------------------------------------------
y = 1
while y <= 1:
    flip = random.randint(0, 1)
    if (flip == 0):
        print("Coin toss goes to ----- Team Rocket to start the attack!")
    if(flip == 1):
        print("Coin toss goes to ----- Team " + playerName + " to start the attack!")
        
    y += 1 
#-------------------------------------------------------------------------------------------------------------------------
# Matchup table
#-------------------------------------------------------------------------------------------------------------------------
def matchupTable(attackType, defenseType):
    if(attackType == "Normal"):
        TE = 1
    if(attackType == "Fire" and (defenseType == "Normal" or defenseType == "Electric")):
        TE = 1
    if(attackType == "Fire" and (defenseType == "Fire" or defenseType == "Water")):
        TE = 0.5
    if(attackType == "Fire" and defenseType == "Grass"):
        TE = 2
    if(attackType == "Water" and (defenseType == "Normal" or defenseType == "Electric")):
        TE = 1
    if(attackType == "Water" and (defenseType == "Grass" or defenseType == "Water")):
        TE = 0.5
    if(attackType == "Water" and defenseType == "Fire"):
        TE = 2   
    if(attackType == "Electric" and (defenseType == "Normal" or defenseType == "Fire")):
        TE = 1
    if(attackType == "Electric" and (defenseType == "Electric" or defenseType == "Grass")):
        TE = 0.5
    if(attackType == "Electric" and defenseType == "Fire"):
        TE = 2
    if(attackType == "Grass" and (defenseType == "Normal" or defenseType == "Electric")):
        TE = 1
    if(attackType == "Grass" and (defenseType == "Fire" or defenseType == "Grass")):
        TE = 0.5
    if(attackType == "Grass" and defenseType == "Water"):
        TE = 2 
    else:
        TE = 1   
    return TE
#-------------------------------------------------------------------------------------------------------------------------
#damage calculation
#-------------------------------------------------------------------------------------------------------------------------
def Damage(power, attack, defense, STAB, moveType, defenseType):
    damage = int(power * (attack/defense) * STAB * (matchupTable(moveType, defenseType) * random.random()))
    return damage
#-------------------------------------------------------------------------------------------------------------------------
# defining team rockets turn and loading all variables from data structures
#-------------------------------------------------------------------------------------------------------------------------
def teamRocketTurn(moveName):
    
    for i in range(0, len(pokemon_moves_data)): #looping through moves data to load in move power, and move type
        if(pokemon_moves_data[i].Name == moveName):
            movePower = float(pokemon_moves_data[i].Power)
            moveType = pokemon_moves_data[i].Type
            
    for i in range(0, len(PokemonList)): #looping through pokemon data to get attack and defense data, and defense type
        if(PokemonList[i].name == teamRocket[0].name):
            attack = float(PokemonList[i].attack)
        if(PokemonList[i].name == playerTeam[0].name):
            defense = float(PokemonList[i].defense)
            defenseType = PokemonList[i].type
            
    STAB = 1 #setting set value fore STAB value

    if(teamRocket[0].type == playerTeam[0].type):  #if opposing pokemon are of the same type then STAB ges set to 1.5
        STAB = 1.5
    damage = Damage(movePower, attack, defense, STAB, moveType, defenseType)
    playerTeam[0].HP = int(playerTeam[0].HP) - damage #recalculating opponent HP after inflicting damage
    
    print("Team Rocket's", teamRocket[0].name, "casts", moveName, "to", playerTeam[0].name)
    print("Damage to", playerTeam[0].name, "is", damage, "points")
    
    if(int(playerTeam[0].HP) <= 0): #if Pokemon faints take it out of team list
        print(playerTeam[0].name, "has fainted back into its pokeball")
        playerTeam.pop(0)
    else:
        print("now", teamRocket[0].name, "has", teamRocket[0].HP, "HP, and", playerTeam[0].name, "has", playerTeam[0].HP, "HP")
    
    print() 
#-------------------------------------------------------------------------------------------------------------------------
# defining team players turn and loading all variables from data structures
#-------------------------------------------------------------------------------------------------------------------------
def teamPlayerTurn(moveName):
    for i in range(0, len(pokemon_moves_data)): #looping through moves data to load in move power, and move type
        if(pokemon_moves_data[i].Name == moveName):
            movePower = float(pokemon_moves_data[i].Power)
            moveType = pokemon_moves_data[i].Type
            
    for i in range(0, len(PokemonList)): #looping through pokemon data to get attack and defense data, and defense type
        if(PokemonList[i].name == playerTeam[0].name):
            attack = float(PokemonList[i].attack)
        if(PokemonList[i].name == teamRocket[0].name):
            defense = float(PokemonList[i].defense)
            defenseType = PokemonList[i].type
            
    STAB = 1 #setting set value fore STAB value

    if(teamRocket[0].type == playerTeam[0].type): #if opposing pokemon are of the same type then STAB ges set to 1.5
        STAB = 1.5
    damage = Damage(movePower, attack, defense, STAB, moveType, defenseType)
    teamRocket[0].HP = int(teamRocket[0].HP) - damage #recalculating opponent HP after inflicting damage
    
    print(playerName, playerTeam[0].name, "casts", moveName, "to", teamRocket[0].name)
    print("Damage to", teamRocket[0].name, "is", damage, "points")
    
    if(int(teamRocket[0].HP) <= 0): #if Pokemon faints take it out of team list
        print(teamRocket[0].name, "has fainted back into its pokeball")
        teamRocket.pop(0)
    else:   
        print("now", playerTeam[0].name, "has", playerTeam[0].HP, "HP, and", teamRocket[0].name, "has", teamRocket[0].HP, "HP")
        
    print()         
#-------------------------------------------------------------------------------------------------------------------------
#Game start
#flip shows team Rocket starts the battle
#-------------------------------------------------------------------------------------------------------------------------
if(flip == 0):
    while((teamRocket != emptyList) and (playerTeam != emptyList)): #loop until either list becomes empty

        if(len(pokemon_moves[teamRocket[0].name]) == 5): #if a pokemon has five moves pick a random number between 0 and 4
            moveNameRocket = pokemon_moves[teamRocket[0].name][random.randint(0,4)]
        elif(len(pokemon_moves[playerTeam[0].name]) == 1): #if a pokemon has one move pick the only move available
            moveNameRocket = pokemon_moves[teamRocket[0].name][0]
        else: #if a pokemon has four moves pick a random number between 0 and 3
            moveNameRocket = pokemon_moves[teamRocket[0].name][random.randint(0,3)]
        teamRocketTurn(moveNameRocket) #team rocket take their turn
#-------Checking to see if either team is out of pokemon-------------------------------------------------------------------
        if(playerTeam == emptyList): 
            print("Team Rocket Wins")
            break
        if(teamRocket == emptyList):
            print("Team", playerName, "Wins")
            break
#-------------------------------------------------------------------------------------------------------------------------
        print("Choose a move for", playerTeam[0].name) 
        if(len(pokemon_moves[playerTeam[0].name]) == 5): #if pokemon has 5 moves display all 5 as options
            print("1.", pokemon_moves[playerTeam[0].name][0])
            print("2.", pokemon_moves[playerTeam[0].name][1])
            print("3.", pokemon_moves[playerTeam[0].name][2])
            print("4.", pokemon_moves[playerTeam[0].name][3])
            print("5.", pokemon_moves[playerTeam[0].name][4])
        elif(len(pokemon_moves[playerTeam[0].name]) == 1): #if pokemon has 1 move display only 1 option is shown
            print("1.", pokemon_moves[playerTeam[0].name][0])
        else:                                               #if pokemon has 4 moves display all 4 as options
            print("1.", pokemon_moves[playerTeam[0].name][0])
            print("2.", pokemon_moves[playerTeam[0].name][1])
            print("3.", pokemon_moves[playerTeam[0].name][2])
            print("4.", pokemon_moves[playerTeam[0].name][3])
    
        moveChoice = input("enter choice: ") #getting user choice of move for counter attack
        print()
    
        if(int(moveChoice) == 1):
            moveName = pokemon_moves[playerTeam[0].name][0] #getting move name for player team parameter
            if(moveName == pokemon_moves[playerTeam[0].name][0]):
                pokemon_moves[playerTeam[0].name][0] = "N/A" #if it has been chosen already then then it gets mark as 'N/A' ( continues all the way down)
        elif(int(moveChoice) == 2):
            moveName = pokemon_moves[playerTeam[0].name][1]
            if(moveName == pokemon_moves[playerTeam[0].name][1]):
                pokemon_moves[playerTeam[0].name][1] = "N/A"
        elif(int(moveChoice) == 3):
            moveName = pokemon_moves[playerTeam[0].name][2]
            if(moveName == pokemon_moves[playerTeam[0].name][2]):
                pokemon_moves[playerTeam[0].name][2] = "N/A"
        elif(int(moveChoice) == 4):
            moveName = pokemon_moves[playerTeam[0].name][3]
            if(moveName == pokemon_moves[playerTeam[0].name][3]):
                pokemon_moves[playerTeam[0].name][3] = "N/A"
        elif(int(moveChoice) == 5):
            moveName = pokemon_moves[playerTeam[0].name][4]
            if(moveName == pokemon_moves[playerTeam[0].name][4]):
                pokemon_moves[playerTeam[0].name][4] = "N/A"
        else:
            print("invalid input") # checks for invalid input
            break
        
        print("choice:", moveName)
        teamPlayerTurn(moveName)
#-------Checking to see if either team is out of pokemon-------------------------------------------------------------------
        if(playerTeam == emptyList):
            print("Team Rocket Wins")
            break
        if(teamRocket == emptyList):
            print("Team", playerName, "Wins")
            break
#-------------------------------------------------------------------------------------------------------------------------       
#-------------------------------------------------------------------------------------------------------------------------
#Game start
#flip shows team Player starts the battle
#-------------------------------------------------------------------------------------------------------------------------          
else:
    while((teamRocket != emptyList) and (playerTeam != emptyList)): #loop until either list becomes empty

        print("Choose a move for", playerTeam[0].name)
        
        if(len(pokemon_moves[playerTeam[0].name]) == 5): #if pokemon has 5 moves display all 5 as options
            print("1.", pokemon_moves[playerTeam[0].name][0])
            print("2.", pokemon_moves[playerTeam[0].name][1])
            print("3.", pokemon_moves[playerTeam[0].name][2])
            print("4.", pokemon_moves[playerTeam[0].name][3])
            print("5.", pokemon_moves[playerTeam[0].name][4])
        elif(len(pokemon_moves[playerTeam[0].name]) == 1): #if pokemon has 1 move display only 1 option is shown
            print("1.", pokemon_moves[playerTeam[0].name][0])
        else:                                               #if pokemon has 4 moves display all 4 as options
            print("1.", pokemon_moves[playerTeam[0].name][0])
            print("2.", pokemon_moves[playerTeam[0].name][1])
            print("3.", pokemon_moves[playerTeam[0].name][2])
            print("4.", pokemon_moves[playerTeam[0].name][3])
    
        moveChoice = input("enter choice: ") #getting user choice of move for counter attack
        print()
    
        if(int(moveChoice) == 1):  #getting move name for player team parameter
            moveName = pokemon_moves[playerTeam[0].name][0]
            if(moveName == pokemon_moves[playerTeam[0].name][0]):
                pokemon_moves[playerTeam[0].name][0] = "N/A" #if it has been chosen already then then it gets mark as 'N/A' ( continues all the way down)
        elif(int(moveChoice) == 2):
            moveName = pokemon_moves[playerTeam[0].name][1]
            if(moveName == pokemon_moves[playerTeam[0].name][1]):
                pokemon_moves[playerTeam[0].name][1] = "N/A"
        elif(int(moveChoice) == 3):
            moveName = pokemon_moves[playerTeam[0].name][2]
            if(moveName == pokemon_moves[playerTeam[0].name][2]):
                pokemon_moves[playerTeam[0].name][2] = "N/A"
        elif(int(moveChoice) == 4):
            moveName = pokemon_moves[playerTeam[0].name][3]
            if(moveName == pokemon_moves[playerTeam[0].name][3]):
                pokemon_moves[playerTeam[0].name][3] = "N/A"
        elif(int(moveChoice) == 5):
            moveName = pokemon_moves[playerTeam[0].name][4]
            if(moveName == pokemon_moves[playerTeam[0].name][4]):
                pokemon_moves[playerTeam[0].name][4] = "N/A"
        else:
            print("invalid input") # checks for invalid input
            break
        
        print("choice:", moveName)
        teamPlayerTurn(moveName) #player turn
#-------Checking to see if either team is out of pokemon-------------------------------------------------------------------
        if(playerTeam == emptyList):
            print("Team Rocket Wins")
            break
        if(teamRocket == emptyList):
            print("Team", playerName, "Wins")
            break
#-------------------------------------------------------------------------------------------------------------------------
        if(len(pokemon_moves[teamRocket[0].name]) == 5): #if pokemon has 5 moves display pick a random number between 0 and 4
            moveNameRocket = pokemon_moves[teamRocket[0].name][random.randint(0,4)]
        elif(len(pokemon_moves[playerTeam[0].name]) == 1): #if pokemon has 1 move pick only option
            moveNameRocket = 0
        else:                                               #if pokemon has 4 moves display pick a random number between 0 and 3
            moveNameRocket = pokemon_moves[teamRocket[0].name][random.randint(0,3)]
        teamRocketTurn(moveNameRocket) #team rocket turn
#-------Checking to see if either team is out of pokemon-------------------------------------------------------------------
        if(playerTeam == emptyList):
            print("Team Rocket Wins")
            break
        if(teamRocket == emptyList):
            print("Team", playerName, "Wins")
            break
#-------------------------------------------------------------------------------------------------------------------------    
    print("game over")