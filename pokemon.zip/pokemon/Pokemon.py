# These necessary properties include name,
# type, HP, attack, defense, moves, and properties of moves


        
        
class Moves(object):
    
    def __init__(self, Name,Type,Category,Contest,PP,Power,Accuracy):
        self.Name = Name
        self.Type = Type
        self.Category = Category
        self.Contest = Contest
        self.PP = PP
        self.Power = Power
        self.Accuracy = Accuracy
        
class Poke(object):
    
    def __init__(self, name, type, HP, attack, defense, moves, height, weight):
        self.name = name
        self.type = type
        self.HP = HP
        self.attack = attack
        self.defense = defense
        self.moves = moves
        self.height = height
        self.weight = weight
        

        